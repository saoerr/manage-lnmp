<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', '123456' );

/** MySQL hostname */
define( 'DB_HOST', '192.168.153.12' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '=MnEub#VR`tJlc(gHoD-nn@EY~U[Z.eDHUQja0}7AeiDnts-/:%;u-E$1?AcCy|r' );
define( 'SECURE_AUTH_KEY',  ';>9_5@8wY:C!;1d3pDR)$-!B?u8(/SxmxF&Vy?|NKI*m@eA%Iy`^ET:l*F(gQeYB' );
define( 'LOGGED_IN_KEY',    't$amK]`;gc/IxH$mG)2!r2gq!o|}q7gHRLM056l]8*/_/t#A1PQSvetjt78Dk2BL' );
define( 'NONCE_KEY',        'z_53k.Tdk&XZ?6>5?H;u`Hu^&N>AjE9Te6?a[V@q_+r@FnZK%&lB;t<3svP#;GNi' );
define( 'AUTH_SALT',        '{gcOkVY%z!,;1NaG#,t~w@+a0gE=p`I*>@zZc(1]g8K^O1EH/=gfKBNgu8S&6Y2w' );
define( 'SECURE_AUTH_SALT', ' V>6A(!X<dG%&kgr8#wzs%3PLT?~]16;kZi|__s#T% #tX&Y*JslMtS8hDE]}PZ+' );
define( 'LOGGED_IN_SALT',   'PwH ~Drzafn)Vl)//WW/|;j9v,%5 Y.z<zj#ih`!^<kx|Q,H|t`wMEV8_7i4<)C^' );
define( 'NONCE_SALT',       'b>hKy&3SLkN%n)a8)CPFHhowr,tH(-Y7iHS~<</*H8:i1 r[mU4z)&:AuT!8.|i[' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp3_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
